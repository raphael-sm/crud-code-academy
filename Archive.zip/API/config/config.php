<?php

$db_conn = new mysqli('database', 'root', '12062009--ra', 'projeto_crud');

$allowedOrigins = [
    'http://0.0.0.0:8080',
    'http://localhost:8080',
    'http://127.0.0.1:8080',
    'http://0.0.0.0:5500',
    'http://localhost:5500',
    'http://127.0.0.1:5500',
];